# Contact Management Application

A simple Flask-based Contact Management System that allows you to add, view, update, and delete contacts.  
Built with **Flask**, **Flask-SQLAlchemy**, and **Flask-WTF**.

---

## Features
- Add new contacts with Name, Email, and Phone Number
- View all saved contacts
- Update contact details
- Delete contacts
- Simple and responsive UI

---

## Tech Stack
- **Backend:** Python, Flask
- **Database:** SQLite (default), can be switched to PostgreSQL/MySQL
- **Frontend:** HTML, Bootstrap (via templates)
- **Forms & Validation:** Flask-WTF, WTForms
- **ORM:** SQLAlchemy

---

## Installation & Setup

### 1️⃣ Clone the Repository
```bash
git clone https://github.com/bhavanabhadane30/contact-manager.git
cd contact-manager
