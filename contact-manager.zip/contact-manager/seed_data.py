from app import db, Contact, normalize_phone

db.create_all()
samples = [
    {"first_name": "Asha", "last_name": "Patel", "email": "asha@example.com", "phone": "+919900112233", "address": "Pune"},
    {"first_name": "Ravi", "last_name": "Kumar", "email": "ravi@example.com", "phone": "9876543210", "address": "Mumbai"},
]
for s in samples:
    p = normalize_phone(s['phone'])
    if not Contact.query.filter((Contact.email == s['email']) | (Contact.phone == p)).first():
        c = Contact(first_name=s['first_name'], last_name=s['last_name'],
                    email=s['email'], phone=p, address=s['address'])
        db.session.add(c)
db.session.commit()
print("Seed data inserted.")
