from flask import Flask, render_template, redirect, url_for, flash, request
from flask_sqlalchemy import SQLAlchemy
from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField, SubmitField
from wtforms.validators import DataRequired, Email, Length, Regexp, Optional
from datetime import datetime
import re
from sqlalchemy.exc import IntegrityError

app = Flask(__name__)
app.config['SECRET_KEY'] = 'CHANGE_THIS_TO_A_RANDOM_SECRET'  # change before production
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///contacts.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

def normalize_phone(p: str) -> str:
    # keep only digits
    return re.sub(r'\D', '', p or '')

class Contact(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    first_name = db.Column(db.String(120), nullable=False)
    last_name = db.Column(db.String(120))
    address = db.Column(db.Text)
    email = db.Column(db.String(120), unique=True, nullable=False)
    phone = db.Column(db.String(30), unique=True, nullable=False)  # stored as digits-only
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f"<Contact {self.first_name} {self.last_name}>"

class ContactForm(FlaskForm):
    first_name = StringField('First name', validators=[DataRequired(), Length(max=120)])
    last_name = StringField('Last name', validators=[Optional(), Length(max=120)])
    address = TextAreaField('Address', validators=[Optional(), Length(max=500)])
    email = StringField('Email', validators=[DataRequired(), Email(), Length(max=120)])
    phone = StringField('Phone', validators=[
        DataRequired(),
        Regexp(r'^[0-9\-\+\s\(\)]{7,20}$', message="Enter a valid phone (7-20 chars: digits, + - ( ) spaces).")
    ])
    submit = SubmitField('Save')

class DeleteForm(FlaskForm):
    submit = SubmitField('Delete')



"""@app.before_first_request
def create_tables():
    db.create_all()"""



@app.route('/')
def index():
    contacts = Contact.query.order_by(Contact.first_name.asc()).all()
    delete_form = DeleteForm()
    return render_template('index.html', contacts=contacts, delete_form=delete_form)

@app.route('/contact/new', methods=['GET', 'POST'])
def create_contact():
    form = ContactForm()
    if form.validate_on_submit():
        phone_norm = normalize_phone(form.phone.data)
        if len(phone_norm) < 7:
            form.phone.errors.append("Phone must have at least 7 digits.")
        else:
            # check duplicates
            q = Contact.query.filter((Contact.email == form.email.data) | (Contact.phone == phone_norm)).first()
            if q:
                if q.email == form.email.data:
                    form.email.errors.append("Email already exists.")
                if q.phone == phone_norm:
                    form.phone.errors.append("Phone already exists.")
            else:
                contact = Contact(
                    first_name=form.first_name.data.strip(),
                    last_name=form.last_name.data.strip(),
                    address=form.address.data.strip(),
                    email=form.email.data.strip().lower(),
                    phone=phone_norm
                )
                db.session.add(contact)
                try:
                    db.session.commit()
                    flash('Contact created successfully.', 'success')
                    return redirect(url_for('index'))
                except IntegrityError:
                    db.session.rollback()
                    flash('Database error while creating contact. Possibly a duplicate.', 'danger')
    return render_template('contact_form.html', form=form, form_title="Create Contact")

@app.route('/contact/<int:contact_id>')
def view_contact(contact_id):
    contact = Contact.query.get_or_404(contact_id)
    delete_form = DeleteForm()
    return render_template('view.html', contact=contact, delete_form=delete_form)

@app.route('/contact/<int:contact_id>/edit', methods=['GET', 'POST'])
def edit_contact(contact_id):
    contact = Contact.query.get_or_404(contact_id)
    form = ContactForm(obj=contact)
    if form.validate_on_submit():
        phone_norm = normalize_phone(form.phone.data)
        if len(phone_norm) < 7:
            form.phone.errors.append("Phone must have at least 7 digits.")
        else:
            # check duplicates excluding this contact
            dup = Contact.query.filter(
                ((Contact.email == form.email.data) | (Contact.phone == phone_norm)) & (Contact.id != contact.id)
            ).first()
            if dup:
                if dup.email == form.email.data:
                    form.email.errors.append("Email already exists.")
                if dup.phone == phone_norm:
                    form.phone.errors.append("Phone already exists.")
            else:
                contact.first_name = form.first_name.data.strip()
                contact.last_name = form.last_name.data.strip()
                contact.address = form.address.data.strip()
                contact.email = form.email.data.strip().lower()
                contact.phone = phone_norm
                try:
                    db.session.commit()
                    flash('Contact updated.', 'success')
                    return redirect(url_for('view_contact', contact_id=contact.id))
                except IntegrityError:
                    db.session.rollback()
                    flash('Database error while updating contact.', 'danger')
    # prefill phone with formatted version if needed (we show digits-only)
    form.phone.data = contact.phone
    return render_template('contact_form.html', form=form, form_title="Edit Contact")

@app.route('/contact/<int:contact_id>/delete', methods=['POST'])
def delete_contact(contact_id):
    form = DeleteForm()
    if form.validate_on_submit():
        contact = Contact.query.get_or_404(contact_id)
        try:
            db.session.delete(contact)
            db.session.commit()
            flash('Contact deleted.', 'success')
        except Exception:
            db.session.rollback()
            flash('Error deleting contact.', 'danger')
    return redirect(url_for('index'))


with app.app_context():
    db.create_all()

if __name__ == '__main__':
    app.run(debug=True)
